package pro.turnoworld.quests;

import org.bukkit.boss.BarColor;
import org.bukkit.entity.EntityType;

public record BossDefinition(String id, String name, EntityType entityType, double health, double damageMultiplier,
                             int skillCooldownSeconds, BarColor barColor) { }
