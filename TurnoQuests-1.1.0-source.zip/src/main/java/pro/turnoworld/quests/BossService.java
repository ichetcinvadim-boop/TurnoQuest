package pro.turnoworld.quests;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class BossService implements Listener {
    private static final String TAG = "turnoquests_boss";
    private final TurnoQuests plugin;
    private final Map<String, BossDefinition> definitions = new LinkedHashMap<>();
    private final Map<UUID, ActiveBoss> active = new java.util.concurrent.ConcurrentHashMap<>();
    private long ticks;

    public BossService(TurnoQuests plugin) {
        this.plugin = plugin;
        define("ICE_EXECUTIONER", "&b&lЛедяной палач", EntityType.STRAY, 450, 1.25, 8, BarColor.BLUE);
        define("HARVEST_LORD", "&2&lПовелитель урожая", EntityType.VINDICATOR, 520, 1.30, 8, BarColor.GREEN);
        define("MINE_COLOSSUS", "&7&lШахтный колосс", EntityType.IRON_GOLEM, 620, 1.45, 9, BarColor.WHITE);
        define("SAND_TITAN", "&e&lПесчаный титан", EntityType.HUSK, 700, 1.50, 8, BarColor.YELLOW);
        define("NIGHT_REAPER", "&5&lНочной жнец", EntityType.WITHER_SKELETON, 760, 1.55, 7, BarColor.PURPLE);
        define("BLOOD_BERSERKER", "&4&lКровавый берсерк", EntityType.PIGLIN_BRUTE, 840, 1.65, 7, BarColor.RED);
        define("RIFT_GUARDIAN", "&d&lСтраж разлома", EntityType.ENDERMAN, 900, 1.70, 6, BarColor.PINK);
        define("THUNDER_LORD", "&3&lПовелитель грома", EntityType.EVOKER, 980, 1.75, 6, BarColor.BLUE);
        define("OMNIRON", "&6&lОмнирон", EntityType.RAVAGER, 1100, 1.90, 5, BarColor.YELLOW);
        define("APOCALYPSE_LORD", "&c&lВладыка Апокалипсиса", EntityType.WITHER, 1250, 2.00, 5, BarColor.RED);
    }

    private void define(String id, String name, EntityType type, double health, double damage, int skill, BarColor color) {
        definitions.put(id, new BossDefinition(id, name, type, health, damage, skill, color));
    }

    public void start() {
        restore();
        plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    public boolean setArena(String id, Player player) {
        BossDefinition definition = definition(id);
        if (definition == null) return false;
        Location l = player.getLocation();
        String path = "bosses.arenas." + definition.id() + ".";
        plugin.getConfig().set(path + "world", l.getWorld().getName());
        plugin.getConfig().set(path + "x", l.getX()); plugin.getConfig().set(path + "y", l.getY()); plugin.getConfig().set(path + "z", l.getZ());
        plugin.getConfig().set(path + "yaw", l.getYaw()); plugin.getConfig().set(path + "pitch", l.getPitch());
        plugin.saveConfig();
        return true;
    }

    public boolean spawn(String id, Player requester) {
        BossDefinition definition = definition(id);
        if (definition == null || active.values().stream().anyMatch(a -> a.definition.id().equals(definition.id()))) return false;
        Location location = arena(definition.id());
        if (location == null) {
            if (requester != null) requester.sendMessage(plugin.color(plugin.prefix() + "&cАрена " + definition.id() + " не установлена. Администратор: /tq boss setarena " + definition.id()));
            return false;
        }
        Entity spawned = location.getWorld().spawnEntity(location, definition.entityType());
        if (!(spawned instanceof LivingEntity entity)) { spawned.remove(); return false; }
        prepare(entity, definition);
        BossBar bar = Bukkit.createBossBar(plugin.color(definition.name()), definition.barColor(), BarStyle.SEGMENTED_10);
        active.put(entity.getUniqueId(), new ActiveBoss(definition, entity, bar, ticks));
        Bukkit.broadcastMessage(plugin.color(plugin.prefix() + "&cПоявился босс: " + definition.name()));
        return true;
    }

    public void stopAll() {
        for (ActiveBoss boss : active.values()) { boss.bar.removeAll(); if (boss.entity.isValid()) boss.entity.remove(); }
        active.clear();
    }

    public BossDefinition definition(String id) { return id == null ? null : definitions.get(id.toUpperCase(Locale.ROOT)); }
    public java.util.Set<String> ids() { return java.util.Collections.unmodifiableSet(definitions.keySet()); }

    private void prepare(LivingEntity entity, BossDefinition definition) {
        entity.addScoreboardTag(TAG);
        entity.addScoreboardTag("tq_boss_" + definition.id().toLowerCase(Locale.ROOT));
        entity.setCustomName(plugin.color(definition.name())); entity.setCustomNameVisible(true); entity.setPersistent(true);
        AttributeInstance max = entity.getAttribute(Attribute.MAX_HEALTH);
        if (max != null) max.setBaseValue(definition.health());
        entity.setHealth(Math.min(definition.health(), max == null ? entity.getHealth() : max.getValue()));
        if (entity instanceof Mob mob) { mob.setAware(true); mob.setRemoveWhenFarAway(false); }
    }

    private void restore() {
        for (World world : Bukkit.getWorlds()) for (Entity raw : world.getEntities()) {
            if (!(raw instanceof LivingEntity entity) || !raw.getScoreboardTags().contains(TAG)) continue;
            BossDefinition definition = null;
            for (String tag : raw.getScoreboardTags()) if (tag.startsWith("tq_boss_")) definition = definition(tag.substring(8));
            if (definition == null) { raw.remove(); continue; }
            BossBar bar = Bukkit.createBossBar(plugin.color(definition.name()), definition.barColor(), BarStyle.SEGMENTED_10);
            active.put(raw.getUniqueId(), new ActiveBoss(definition, entity, bar, ticks));
        }
    }

    private Location arena(String id) {
        String path = "bosses.arenas." + id + ".";
        String worldName = plugin.getConfig().getString(path + "world", "");
        World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        return new Location(world, plugin.getConfig().getDouble(path + "x"), plugin.getConfig().getDouble(path + "y"), plugin.getConfig().getDouble(path + "z"),
                (float) plugin.getConfig().getDouble(path + "yaw"), (float) plugin.getConfig().getDouble(path + "pitch"));
    }

    private void tick() {
        ticks++;
        for (ActiveBoss boss : java.util.List.copyOf(active.values())) {
            if (!boss.entity.isValid() || boss.entity.isDead()) { remove(boss.entity.getUniqueId()); continue; }
            AttributeInstance max = boss.entity.getAttribute(Attribute.MAX_HEALTH);
            double maximum = max == null ? boss.definition.health() : max.getValue();
            boss.bar.setProgress(Math.max(0, Math.min(1, boss.entity.getHealth() / maximum)));
            boss.bar.removeAll();
            for (Entity nearby : boss.entity.getWorld().getNearbyEntities(boss.entity.getLocation(), 64, 64, 64)) if (nearby instanceof Player player) boss.bar.addPlayer(player);
            if (ticks - boss.lastSkillTick >= boss.definition.skillCooldownSeconds()) {
                useSkill(boss);
                boss.lastSkillTick = ticks;
            }
        }
    }

    private void useSkill(ActiveBoss boss) {
        for (Entity nearby : boss.entity.getWorld().getNearbyEntities(boss.entity.getLocation(), 12, 8, 12)) {
            if (!(nearby instanceof Player player)) continue;
            switch (boss.definition.id()) {
                case "ICE_EXECUTIONER" -> player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 1));
                case "HARVEST_LORD" -> player.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 80, 0));
                case "MINE_COLOSSUS" -> knockback(boss.entity, player, 1.7);
                case "SAND_TITAN" -> player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 80, 0));
                case "NIGHT_REAPER" -> player.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 100, 0));
                case "BLOOD_BERSERKER" -> heal(boss.entity, 20);
                case "RIFT_GUARDIAN" -> player.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 40, 0));
                case "THUNDER_LORD" -> { player.getWorld().strikeLightningEffect(player.getLocation()); player.damage(6, boss.entity); }
                case "OMNIRON" -> { player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 1)); knockback(boss.entity, player, 2.0); }
                case "APOCALYPSE_LORD" -> { player.setFireTicks(100); player.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 100, 1)); player.damage(8, boss.entity); }
                default -> { }
            }
        }
    }

    private void knockback(LivingEntity source, Player target, double force) {
        Vector vector = target.getLocation().toVector().subtract(source.getLocation().toVector()).normalize().multiply(force).setY(0.55);
        target.setVelocity(vector);
    }
    private void heal(LivingEntity entity, double amount) { AttributeInstance max = entity.getAttribute(Attribute.MAX_HEALTH); entity.setHealth(Math.min(max == null ? entity.getHealth() : max.getValue(), entity.getHealth() + amount)); }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        ActiveBoss attacker = active.get(event.getDamager().getUniqueId());
        if (attacker != null) event.setDamage(event.getDamage() * attacker.definition.damageMultiplier());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent event) {
        if (event.getEntity().getScoreboardTags().contains(TAG)) event.blockList().clear();
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent event) {
        ActiveBoss boss = active.get(event.getEntity().getUniqueId());
        if (boss == null && !event.getEntity().getScoreboardTags().contains(TAG)) return;
        String id = boss == null ? bossId(event.getEntity()) : boss.definition.id();
        Map<UUID, Double> damage = plugin.consumeBossDamage(event.getEntity().getUniqueId());
        double total = damage.values().stream().mapToDouble(Double::doubleValue).sum();
        double minimum = plugin.getConfig().getDouble("anti-exploit.boss-minimum-contribution-percent", 10) / 100D;
        boolean credited = false;
        for (Map.Entry<UUID, Double> entry : damage.entrySet()) {
            if (total <= 0 || entry.getValue() / total + 1.0E-9 < minimum) continue;
            Player player = Bukkit.getPlayer(entry.getKey());
            if (player != null && player.getWorld().equals(event.getEntity().getWorld()) && player.getLocation().distanceSquared(event.getEntity().getLocation()) <= 128 * 128) {
                plugin.record(player, QuestType.BOSS_KILL, id, 1); credited = true;
            }
        }
        if (!credited && event.getEntity().getKiller() != null) plugin.record(event.getEntity().getKiller(), QuestType.BOSS_KILL, id, 1);
        remove(event.getEntity().getUniqueId());
    }

    private String bossId(Entity entity) { for (String tag : entity.getScoreboardTags()) if (tag.startsWith("tq_boss_")) return tag.substring(8).toUpperCase(Locale.ROOT); return "UNKNOWN"; }
    private void remove(UUID uuid) { ActiveBoss removed = active.remove(uuid); if (removed != null) removed.bar.removeAll(); }
    public void shutdown() { for (ActiveBoss boss : active.values()) boss.bar.removeAll(); active.clear(); }

    private static final class ActiveBoss {
        final BossDefinition definition; final LivingEntity entity; final BossBar bar; long lastSkillTick;
        ActiveBoss(BossDefinition definition, LivingEntity entity, BossBar bar, long tick) { this.definition = definition; this.entity = entity; this.bar = bar; this.lastSkillTick = tick; }
    }
}
