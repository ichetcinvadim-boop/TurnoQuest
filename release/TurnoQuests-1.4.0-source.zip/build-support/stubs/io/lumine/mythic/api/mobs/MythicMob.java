package io.lumine.mythic.api.mobs; public interface MythicMob { String getInternalName(); }
