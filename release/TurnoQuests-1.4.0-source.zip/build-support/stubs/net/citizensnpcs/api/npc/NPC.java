package net.citizensnpcs.api.npc; public interface NPC { int getId(); }
