package net.milkbowl.vault.economy; public class EconomyResponse { public boolean transactionSuccess(){return false;} }
