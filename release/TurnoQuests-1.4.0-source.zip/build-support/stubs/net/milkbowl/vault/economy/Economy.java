package net.milkbowl.vault.economy; import org.bukkit.OfflinePlayer; public interface Economy { EconomyResponse depositPlayer(OfflinePlayer p,double a); String format(double a); }
