package net.md_5.bungee.api; public enum ChatMessageType { ACTION_BAR }
