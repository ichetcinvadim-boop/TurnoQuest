package net.md_5.bungee.api.chat; public class TextComponent extends BaseComponent { public static BaseComponent[] fromLegacyText(String s){return null;} }
