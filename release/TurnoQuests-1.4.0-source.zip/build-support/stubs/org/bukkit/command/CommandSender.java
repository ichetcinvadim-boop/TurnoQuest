package org.bukkit.command; public interface CommandSender { void sendMessage(String s); boolean hasPermission(String s); String getName(); }
