package org.bukkit.entity; import java.util.UUID; public interface AnimalTamer { UUID getUniqueId(); String getName(); }
