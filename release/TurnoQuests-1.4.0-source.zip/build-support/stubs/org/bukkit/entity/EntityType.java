package org.bukkit.entity; public enum EntityType { VILLAGER, ZOMBIE, SKELETON, PLAYER; }
