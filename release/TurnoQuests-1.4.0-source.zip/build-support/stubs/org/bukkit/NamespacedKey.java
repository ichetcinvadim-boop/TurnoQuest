package org.bukkit; public class NamespacedKey { public static NamespacedKey fromString(String s){return null;} public String getKey(){return "";} @Override public String toString(){return "";} }
