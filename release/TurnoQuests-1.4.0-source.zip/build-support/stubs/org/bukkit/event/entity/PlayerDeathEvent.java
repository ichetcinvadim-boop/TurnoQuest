package org.bukkit.event.entity; import org.bukkit.entity.Player; import org.bukkit.event.Event; public class PlayerDeathEvent extends Event { public Player getEntity(){return null;} }
