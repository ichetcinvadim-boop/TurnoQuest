package org.bukkit.event.entity; import org.bukkit.entity.LivingEntity; import org.bukkit.event.Event; public class EntityDeathEvent extends Event { public LivingEntity getEntity(){return null;} }
