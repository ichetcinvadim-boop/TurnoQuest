package org.bukkit; public interface Chunk { boolean load(); }
