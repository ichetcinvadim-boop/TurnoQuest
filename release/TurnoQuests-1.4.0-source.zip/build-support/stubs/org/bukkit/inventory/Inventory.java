package org.bukkit.inventory; public interface Inventory { InventoryHolder getHolder(); void setItem(int s,ItemStack i); int getSize(); }
