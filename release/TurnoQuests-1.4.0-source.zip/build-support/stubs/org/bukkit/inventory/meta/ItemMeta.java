package org.bukkit.inventory.meta; import java.util.List; public interface ItemMeta { void setDisplayName(String s); void setLore(List<String> l); }
