package org.bukkit.inventory;
public interface InventoryView { }
