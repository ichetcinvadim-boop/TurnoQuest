package org.bukkit.inventory; public interface PlayerInventory extends Inventory { int firstEmpty(); }
