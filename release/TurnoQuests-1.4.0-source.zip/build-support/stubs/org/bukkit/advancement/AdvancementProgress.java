package org.bukkit.advancement; public interface AdvancementProgress { boolean isDone(); }
