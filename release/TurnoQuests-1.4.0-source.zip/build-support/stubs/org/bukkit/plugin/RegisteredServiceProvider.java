package org.bukkit.plugin; public interface RegisteredServiceProvider<T> { T getProvider(); }
