package org.bukkit; public enum ChatColor {; public static String translateAlternateColorCodes(char c, String s){return s;} }
