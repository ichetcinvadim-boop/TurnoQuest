package org.bukkit.block; import org.bukkit.Location; import org.bukkit.Material; public interface Block { Material getType(); Location getLocation(); Biome getBiome(); }
