package org.bukkit.block; import org.bukkit.NamespacedKey; public enum Biome { DESERT, BADLANDS, DEEP_DARK, CHERRY_GROVE, END_HIGHLANDS, PLAINS; public NamespacedKey getKey(){return null;} }
